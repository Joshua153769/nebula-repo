Welcome to Nebula Linux 1.0 (Pluto)

This home folder was created from /etc/skel.
You can customize your environment, and future users will still start from a clean, calm default.

Nebula Linux
